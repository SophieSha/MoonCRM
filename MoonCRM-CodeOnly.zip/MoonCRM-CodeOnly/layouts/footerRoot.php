 <!-- jQuery  -->
        <script src="public/assets/js/jquery.min.js"></script>
        <script src="public/assets/js/bootstrap.bundle.min.js"></script>
        <script src="public/assets/js/metisMenu.min.js"></script>
        <script src="public/assets/js/jquery.slimscroll.js"></script>
        <script src="public/assets/js/waves.min.js"></script>
         <!-- countdown -->
         <script src="public/plugins/countdown/jquery.countdown.min.js"></script>
        <script src="public/assets/pages/countdown.int.js"></script>

        <!-- App js -->
        <script src="public/assets/js/app.js"></script>

