<footer class="footer">
         © <?php echo date("Y",strtotime("-1 year")); ?> - <?php echo date("Y"); ?> MoonCRM <span class="text-muted d-none d-sm-inline-block float-right">by Mooncake</span>
</footer>