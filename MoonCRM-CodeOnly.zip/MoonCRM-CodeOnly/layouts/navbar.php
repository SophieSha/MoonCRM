

  <!-- ========== Left Sidebar Start ========== -->
   <div  class="left side-menu" >


   <!-- LOGO -->
   <div class="topbar-left" >
   <h2 class="title"><a href="home.php" style="color: #FED766"> MoonCRM </a></h2>
    <div class=""  style="text-align: 20px">
        <a href="home.php" class="logo"  ><img src="public/assets/images/mooncrm-Logo.png" height="50" alt="logo"></a>
      </div>
    </div>


   <!-- Nav memu list -->

    <div id="sidebar-menu">
       
        <ul>
                    
        <li><a href="home.php"><i class="mdi mdi-newspaper"></i><span> Home </span></a></li>
        <li><a href="customer.php"><i class=" mdi mdi-account-multiple"></i><span> Customer </span></a></li>
        <li><a href="task.php"><i class=" mdi mdi-format-list-bulleted"></i><span> Task </span></a></li>
        <li><a href="order.php"><i class="mdi mdi-cart"></i><span> Order </span></a></li>
        <li><a href='inventory.php'><i class=" mdi mdi-barcode"></i><span> Inventory </span></a></li>
        <li><a href="widget.php"><i class="mdi mdi-apps"></i><span> Widget </span></a></li>
        <li><a href="admin.php"><i class=" mdi mdi-border-color"></i><span> Admin </span></a></li>

       
    </ul>
    </div>
    <div class="clearfix"></div>
</div> <!-- end sidebarinner -->
</div>
<!-- Left Sidebar End -->
